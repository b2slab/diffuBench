library(testthat)
library(diffuStats)

test_check("diffuStats")
